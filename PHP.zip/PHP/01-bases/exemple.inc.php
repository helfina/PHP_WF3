<p style="color:red;">Ici, on peut ecrire n'importe quoi, mais l'idee serait d'y mettre du contenu HTML et /ou des traitements PHP</p>   
