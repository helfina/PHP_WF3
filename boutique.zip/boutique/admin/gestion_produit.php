<?php require_once "../inc/header.inc.php"; ?>
<?php
//Restriction de l'accès à la page :
if( !adminConnect() ){ //SI l'admin N'EST PAS connecté, alors on le redirige vers la page de connexion

    header("location:../connexion.php");
    exit;    
}

//-----------------------------------------------------
//Gestion des produits : INSERTION
if( !empty( $_POST ) ){ //SI le formulaire a été validé et qu'il N'EST PAS vide

    debug( $_POST );

    //Controles sur les saisies (il faudrait faire pour chaque input)
    //EXERCICE : Faites en sorte d'afficher un message d'erreur si la référence postée existe déjà :
    $r = execute_requete("SELECT reference FROM produit WHERE reference = '$_POST[reference]' ");
    //ICi, on sélectionne la référence de la table 'produit' A CONDITION que dans la colonne 'reference', ce soit égale à ce que l'utilisateur a saisi

    if( $r->rowCount() >= 1 ){ //SI le jeu de résultat (ici, $r) retourné par la requête est supérieur ou égal à 1, c'est que la référence a été trouvé en BDD et donc on aura une ligne de résultat que me retourne la methode rowCount()

        $error .= "<div class='alert alert-danger'>Référence indisponible </div>";
    }

    //-----------------------------------------------------
    //On passe toutes les infos postées par l'admin dans les fontions addslashes() et htmlentities()
    foreach( $_POST as $index => $value ){

        $_POST[ $index ] = htmlentities( addslashes( $value ) ); 
    }

    //-----------------------------------------------------
    //GESTION de la photo
        debug( $_FILES );
        //debug( $_SERVER );

        if( !empty( $_FILES['photo']['name'] ) ){ //SI le nom de la photo dans $_FILES N'EST PAS VIDE, c'est que l'on a téléchargé un fichier

            //Ici, je renomme la photo (avec la ref)
            $nom_photo = $_POST['reference'] .'_'. $_FILES['photo']['name'];
            //$_POST['reference'] corresopnd à la référence saisie par l'admin
            //$_FILES['photo']['name'] correspond au nom du fichier téléchargé
                debug( $nom_photo );

            //Chemin pour accéder à la photo (à insérer en BDD)
            $photo_bdd = URL ."photo/" . $nom_photo;
            //constante URL <=> http://localhost/PHP/boutique/
                debug( $photo_bdd );

                // http://localhost/PHP/boutique/photo/photo.png

            //Chemin où l'on souhaite enregistrer notre fichier "physique" de la photo
            $photo_dossier = $_SERVER['DOCUMENT_ROOT'] . "/PHP/boutique/photo/" . $nom_photo;
                debug( $photo_dossier );
            //$_SERVER : superglobale de php qui retourne des infos sur le serveur courant
            //$_SERVER['DOCUMENT_ROOT']  <=> C:/xampp/htdocs
            

                // C:/xampp/htdocs/PHP/boutique/photo/photo.png

        }
        else{ //SINON, c'est que l'on a pas télécharger de fichier et donc on affiche un message d'erreur

            $error .= "<div class='alert alert-danger'> Vuos n'avez pas uploader de photo</div>";
        }


    //-----------------------------------------------------
    if( empty( $error ) ){ //SI la variable $error est vide, on fait une insertion

        // execute_requete(" 
        
        // INSERT INTO produit( reference, categorie, titre, description, couleur, taille, sexe, photo, prix, stock )
        //             VALUES(
        //                     '$_POST[reference]',
        //                     '$_POST[categorie]',
        //                     '$_POST[titre]',
        //                     '$_POST[description]',
        //                     '$_POST[couleur]',
        //                     '$_POST[taille]',
        //                     '$_POST[sexe]',
        //                     '$_POST[photo]',
        //                     '$_POST[prix]',
        //                     '$_POST[stock]'
        //             )
        // ");
    }
       
}

//---------------------------------------------------------------
?>

<h1>GESTION DES PRODUITS</h1>

<?= $error; //afficahge des erreurs ?>

<form method="post" enctype="multipart/form-data">
<!-- enctype="multipart/form-data" : cet attribut est OBLIGATOIRE lorsque l'on souhaite uplaoder des fichiers et les récupérer via $_FILES -->

    <label>Référence</label><br>
    <input type="text" name="reference" ><br>

    <label>Catégorie</label><br>
    <input type="text" name="categorie" ><br>

    <label>Titre</label><br>
    <input type="text" name="titre" ><br>

    <label>Description</label><br>
    <input type="text" name="description" ><br>

    <label>Couleur</label><br>
    <input type="text" name="couleur" ><br>

    <label>Taille</label><br>
    <select name="taille" >
        <option value="S">S</option>
        <option value="M">M</option>
        <option value="L">L</option>
        <option value="XL">XL</option>
    </select><br><br>

    <label>Civilite</label><br>
    <input type="radio" name="sexe" value="m" checked >Homme<br>
    <input type="radio" name="sexe" value="f">Femme<br><br>

    <label>Photo</label><br>
    <input type="file" name="photo" ><br>

    <label>Prix</label><br>
    <input type="text" name="prix" ><br>

    <label>Stock</label><br>
    <input type="text" name="stock" ><br><br>

    <input type="submit" value="valider" class="btn btn-secondary">
</form>

<?php require_once "../inc/footer.inc.php"; ?>