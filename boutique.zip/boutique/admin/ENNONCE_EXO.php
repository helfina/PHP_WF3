<?php

/*
EXERCICE : création de la page gestion_membre.php

Objectifs : 

	- L'accès à la page doit être accéssible uniquement si l'on est administtrateur

	- Afficher les membres (sans le mot de passe)
		-> Avoir la possibilité de supprimer un membre
		-> Avoir la possibilité de modififer un membre
			( comme pour pouvoir changer le statut d'un membre)
*/

//------------------------------------------------------------------------

//EXERCICE : créer la page gestion des commandes :
//restriction d'accès à la page admin :

//-------------------------------------------------
//Affichage des commandes (sous forme de tableau) prevoir un lien (sur l'id_commande) pour afficher le détail de la commande 

//-------------------------------------------------
//affichage du détail de la commande :
//debug( $_GET );