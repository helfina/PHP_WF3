<?php require_once 'inc/header.inc.php'; //inclusion du fichier 'header.inc.php' ?>

  <h1>Bienvenu sur mon site</h1>

<?php require_once 'inc/footer.inc.php'; //inclusion du fichier 'footer.inc.php' ?>